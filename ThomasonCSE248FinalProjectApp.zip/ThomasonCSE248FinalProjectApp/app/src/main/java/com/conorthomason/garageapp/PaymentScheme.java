package com.conorthomason.garageapp;

public enum PaymentScheme {
	CASH, CHECK, DEBIT, CREDIT;
}
