package p3;

public interface Observer {
	void update(int value);
}